#include <iostream>
#include <string>
#include <vector>
#include <stdexcept>
#include "csapp.h"
#include "message.h"
#include "connection.h"
#include "client_util.h"

int main(int argc, char **argv) {
  if (argc != 5) {
    std::cerr << "Usage: ./receiver [server_address] [port] [username] [room]\n";
    return 1;
  }

  std::string server_hostname = argv[1];
  int server_port = std::stoi(argv[2]);
  std::string username = argv[3];
  std::string room_name = argv[4];

  Connection conn;

  // TODO: connect to server
  conn.connect(server_hostname, server_port);
  if (!conn.is_open()) {
    std::cerr << "Couldn't connect at server at " << server_hostname << ":" << server_port << "\n";
    return 1;
  }

  // TODO: send rlogin and join messages (expect a response from
  //       the server for each one)
  Message rlogin_msg(TAG_RLOGIN, username);
  if (!conn.send(rlogin_msg)) {
    std::cerr << rlogin_msg.data << "Failed to send rlogin message\n";
    conn.close();
    return 1;
  }

  Message rlogin_resp;
  if (!conn.receive(rlogin_resp)) {
    std::cerr << rlogin_resp.data << "\n";
    conn.close();
    return 1;
  }

  Message join_msg(TAG_JOIN, room_name);

  if (!conn.send(join_msg)) {
    std::cerr << "Failed to send join message\n";
    conn.close();
    return 1;
  }

  Message join_resp;
  if (!conn.receive(join_resp)) {
    std::cerr << "Failed to receive join response\n";
    conn.close();
    return 1;
  }

  if (join_resp.tag == TAG_ERR) {
    std::cerr << join_resp.data << "\n";
    conn.close();
    return 1;
  }
  // TODO: loop waiting for messages from server
  //       (which should be tagged with TAG_DELIVERY)
  
  Message server_msg; //room:sender:message_text
  while (conn.receive(server_msg)) {
    if (server_msg.tag == TAG_DELIVERY) {
      std::string data = server_msg.data;
      size_t room_sep_colon = data.find(':');
      if (room_sep_colon == std::string::npos) {
        std::cerr << "Missign room from server message\n";
        continue;
      }

      size_t sender_sep_colon = data.find(':', room_sep_colon + 1);
      if (sender_sep_colon == std::string::npos) {
        std::cerr << "Missing sender from server message\n";
        continue;
      }

      std::string sender = data.substr(room_sep_colon + 1, sender_sep_colon - (room_sep_colon + 1));
      std::string msg_text = data.substr(sender_sep_colon + 1);
      std::cout << sender << ": " << msg_text << "\n";
    } else if (server_msg.tag == TAG_ERR) {
      std::cerr << "Error from server: " << server_msg.data << "\n";
    } else {
      std::cerr << "Unknown case\n";
    }
  }



  conn.close();
  return 0;
}